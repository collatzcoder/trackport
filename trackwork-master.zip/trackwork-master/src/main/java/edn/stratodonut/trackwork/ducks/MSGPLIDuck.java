package edn.stratodonut.trackwork.ducks;

public interface MSGPLIDuck {
    public void tallyho$setAboveGroundTickCount(int value);
}
